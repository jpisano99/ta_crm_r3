#
# A place to keep API keys and passwords # Passwords
#

passwords = dict(
    DB_PASSWORD="database_password_123",
    USER_PASSWORD = "password",
    SS_TOKEN="API_key_abc"
)
